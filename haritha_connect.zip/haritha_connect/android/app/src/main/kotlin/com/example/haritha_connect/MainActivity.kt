package com.example.haritha_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
